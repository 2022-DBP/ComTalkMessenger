﻿
namespace Chatting_Form
{
    partial class FormChattingRoom
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.listBoxMember = new System.Windows.Forms.ListBox();
            this.textBoxMyID = new System.Windows.Forms.TextBox();
            this.Info = new System.Windows.Forms.Label();
            this.textBoxIPAdress = new System.Windows.Forms.TextBox();
            this.buttonConnect = new System.Windows.Forms.Button();
            this.buttonChattingStart = new System.Windows.Forms.Button();
            this.listBoxRoom = new System.Windows.Forms.ListBox();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(70, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "대화 상대";
            // 
            // listBoxMember
            // 
            this.listBoxMember.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.listBoxMember.FormattingEnabled = true;
            this.listBoxMember.ItemHeight = 20;
            this.listBoxMember.Location = new System.Drawing.Point(72, 88);
            this.listBoxMember.Name = "listBoxMember";
            this.listBoxMember.Size = new System.Drawing.Size(297, 224);
            this.listBoxMember.TabIndex = 8;
            this.listBoxMember.SelectedIndexChanged += new System.EventHandler(this.listBoxMember_SelectedIndexChanged);
            // 
            // textBoxMyID
            // 
            this.textBoxMyID.Location = new System.Drawing.Point(215, 27);
            this.textBoxMyID.Name = "textBoxMyID";
            this.textBoxMyID.Size = new System.Drawing.Size(100, 25);
            this.textBoxMyID.TabIndex = 11;
            // 
            // Info
            // 
            this.Info.AutoSize = true;
            this.Info.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Info.ForeColor = System.Drawing.Color.White;
            this.Info.Location = new System.Drawing.Point(70, 9);
            this.Info.Name = "Info";
            this.Info.Size = new System.Drawing.Size(74, 20);
            this.Info.TabIndex = 12;
            this.Info.Text = "대화 상대";
            // 
            // textBoxIPAdress
            // 
            this.textBoxIPAdress.Location = new System.Drawing.Point(216, 57);
            this.textBoxIPAdress.Name = "textBoxIPAdress";
            this.textBoxIPAdress.Size = new System.Drawing.Size(100, 25);
            this.textBoxIPAdress.TabIndex = 13;
            // 
            // buttonConnect
            // 
            this.buttonConnect.Location = new System.Drawing.Point(321, 26);
            this.buttonConnect.Name = "buttonConnect";
            this.buttonConnect.Size = new System.Drawing.Size(75, 56);
            this.buttonConnect.TabIndex = 14;
            this.buttonConnect.Text = "button1";
            this.buttonConnect.UseVisualStyleBackColor = true;
            this.buttonConnect.Click += new System.EventHandler(this.buttonConnect_Click);
            // 
            // buttonChattingStart
            // 
            this.buttonChattingStart.Location = new System.Drawing.Point(283, 516);
            this.buttonChattingStart.Name = "buttonChattingStart";
            this.buttonChattingStart.Size = new System.Drawing.Size(86, 33);
            this.buttonChattingStart.TabIndex = 15;
            this.buttonChattingStart.Text = "채팅 시작";
            this.buttonChattingStart.UseVisualStyleBackColor = true;
            this.buttonChattingStart.Click += new System.EventHandler(this.buttonChattingStart_Click);
            // 
            // listBoxRoom
            // 
            this.listBoxRoom.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.listBoxRoom.FormattingEnabled = true;
            this.listBoxRoom.ItemHeight = 20;
            this.listBoxRoom.Location = new System.Drawing.Point(72, 332);
            this.listBoxRoom.Name = "listBoxRoom";
            this.listBoxRoom.Size = new System.Drawing.Size(297, 164);
            this.listBoxRoom.TabIndex = 16;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(191, 516);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(86, 33);
            this.button1.TabIndex = 17;
            this.button1.Text = "채팅 시작";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // FormChattingRoom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.ClientSize = new System.Drawing.Size(398, 561);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.listBoxRoom);
            this.Controls.Add(this.buttonChattingStart);
            this.Controls.Add(this.buttonConnect);
            this.Controls.Add(this.textBoxIPAdress);
            this.Controls.Add(this.Info);
            this.Controls.Add(this.textBoxMyID);
            this.Controls.Add(this.listBoxMember);
            this.Controls.Add(this.label1);
            this.ForeColor = System.Drawing.Color.Black;
            this.Name = "FormChattingRoom";
            this.Text = "대화방";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox listBoxMember;
        private System.Windows.Forms.TextBox textBoxMyID;
        private System.Windows.Forms.Label Info;
        private System.Windows.Forms.TextBox textBoxIPAdress;
        private System.Windows.Forms.Button buttonConnect;
        private System.Windows.Forms.Button buttonChattingStart;
        private System.Windows.Forms.ListBox listBoxRoom;
        private System.Windows.Forms.Button button1;
    }
}

