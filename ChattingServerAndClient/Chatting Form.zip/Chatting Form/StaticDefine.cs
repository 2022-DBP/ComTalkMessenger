﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chatting_Form
{
    class StaticDefine
    {
        public const int ONE_ON_ONE_CHATTING = 1;
        public const int GROUP_CHATTING = 2;
    }
}
